#!/bin/bash

SUCESSO=0
ERRO=1

source ${LIBSH}/connection_hive.properties

#Funcao que realiza o load dos dados no HIVE
#
# $1 sql script SQL com o insert/select
# 
# retorno 0 se OK, 1 caso contrario
function loadData {

    insert_query="add jar /usr/local/hive/lib/hive-contrib.jar;
set mapreduce.map.speculative=false;
set mapreduce.reduce.speculative=false;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.max.dynamic.partitions.pernode=1000;
set hive.exec.max.created.files=3000;
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles=true;
set hive.merge.size.per.task=256000000;
set hive.merge.smallfiles.avgsize=60000000;
$1
$2"

	logInfo "Insert Query: $insert_query"
	
	logInfo "------------------------"
	logInfo "Executando insert..."
	
	#file_insert=./../tmp/file_insert_$(date +%s).hql

    #echo "$insert_query" >> $file_insert

#    hive -e "$insert_query"

    beeline -u jdbc:hive2://$hive_host -n $hive_username -p $hive_password -e "$insert_query"

    #rm $file_insert

    #limpaTemp
	
	if [ $? -ne 0 ]
	then
		logError "Could not insert data from $hive_staging_dir to managed table"
	    return $ERRO
	fi
	
	logInfo "Insert executed with success!"
	
	return $SUCESSO
}


#Funcao utilizada para limpar o diretorio staging apos concluir a ingestao para a tabela gerenciada
#
# $1 staging pasta de staging
# 
# retorno 0 se OK, 1 caso contrario
function limpaStaging {
	staging=$1
	logInfo "Deleting the directories: $staging"
	hadoop fs -rm -r -skipTrash $staging

	return $SUCESSO
}

#Funcao utilizada para limpar o diretorio temporario utilizado para geracao de arquivos para beeline
#Exclui arquivos armazenados a mais de 1 dia (em caso de queda do servidor ou falha do processo)
function limpaTemp {
        logInfo "Deleting the files temporary..."
        find ./../tmp/ -type f -mtime +1 -exec rm {} \;
}