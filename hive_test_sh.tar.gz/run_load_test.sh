#!/bin/bash

pathSource=$(dirname $( readlink -f "$0"))

source $pathSource/lib-sh/setup.sh

. ${LIBSH}/commons.sh
. ${LIBSH}/exit-if-ne-0.sh
. ${LIBSH}/hive_load_xml.sh
. ${LIBSH}/hive_commons.sh
. ${LIBSH}/hive_copy_data.sh
. ${LIBSH}/hive_load_data.sh

if [ ! -d "$pathSource/lib-sh_bkp/" ]
then
    cp -rf $pathSource/lib-sh $pathSource/lib-sh_bkp
    cp -f $pathSource/lib-test/* $pathSource/lib-sh/
    sed -e '/setup.sh/ s/^#*/#/' -i $pathSource/run_load_hive.sh
    sed -i "3isource $pathSource/lib-sh/setup.sh" $pathSource/run_load_hive.sh
fi

cd $pathSource/../resources/
#Initialize xml configuration
for f in `ls *.xml`;
do
    echo [ TEST ] `date '+%Y-%m-%d %H:%M:%S'` - iniciando teste com $f
    initializeConfig $pathSource/../resources/$f

    echo [ TEST ] `date '+%Y-%m-%d %H:%M:%S'` - criando databases no hive
    managed_table_name=$(getConfigValue "managed-table-name")
    external_table_name=$(getConfigValue "external-table-name")
    managed_db="create database "$(echo $managed_table_name|cut -d "." -f1)
    external_db="create database "$(echo $external_table_name|cut -d "." -f1)
    hive -e "$managed_db;$external_db;"

    echo [ TEST ] `date '+%Y-%m-%d %H:%M:%S'` - criando path hdfs
    base_incoming_path=$(getConfigValue "base-incoming-path")
    hdfs dfs -mkdir -p $base_incoming_path

    echo [ TEST ] `date '+%Y-%m-%d %H:%M:%S'` - criando tabelas
    hive -f $pathSource/../hql/*.hql

    echo [ TEST ] `date '+%Y-%m-%d %H:%M:%S'` - colocando arquivo para carga
    filename_prefix=$(getConfigValue "filename-prefix")
    file_extension-format=$(getConfigValue "file-extension-format")
    hdfs dfs -put "$pathSource/../landing/$filename_prefix*$file_extensionformat" $base_incoming_path

    echo [ TEST ] `date '+%Y-%m-%d %H:%M:%S'` - iniciando procedimento de ingestao
    $pathSource/run_load_hive.sh $1
    echo [ TEST ] `date '+%Y-%m-%d %H:%M:%S'` - "fim do procedimento de ingestao"
    
    done